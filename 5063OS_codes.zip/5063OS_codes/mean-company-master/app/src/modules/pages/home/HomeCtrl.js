/**
@module ang-home
@class ang-home
*/

'use strict';

angular.module('myApp').controller('HomeCtrl', ['$scope', function($scope) {
}]);